
// Crear una función con tres parámetros que sean números que se suman entre sí".
// llamar a la función en el Main y darle valores.
class Main {
    public static void main(String[] args) {
        int ni = 10;
        int nj = 57;
        int nk = 43;
        sumarTresNumeros(ni,nj,nk);
    }
    
    public static void sumarTresNumeros(int i,int j, int k){
        System.out.println(i+j+k);
        
    }
}